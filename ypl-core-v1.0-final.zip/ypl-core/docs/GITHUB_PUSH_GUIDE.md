# 📤 GitHub Push Guide

**ТЗ #YPL-GITHUB-INIT-03 — Инструкция для команды**

---

## 🎯 Цель

Загрузить проект YPL CORE в существующий репозиторий:  
👉 **https://github.com/Solarpaletten/ypl.git**

---

## 📋 Предварительные требования

### Что должно быть установлено:

```bash
# Проверить Git
git --version
# Должно показать: git version 2.x.x

# Проверить Node.js
node --version
# Должно показать: v18.x.x или выше

# Проверить npm
npm --version
# Должно показать: 9.x.x или выше
```

### Что должно быть готово:

- [ ] Аккаунт GitHub (Solarpaletten)
- [ ] SSH ключ или токен настроен
- [ ] Архив ypl-core.zip скачан

---

## 🚀 Пошаговая инструкция

### Вариант A: Если репозиторий пустой

```bash
# ═══════════════════════════════════════════════════════════
# ШАГИ ДЛЯ VASIL ИЛИ LEANID
# ═══════════════════════════════════════════════════════════

# 1️⃣ Клонировать репозиторий
git clone https://github.com/Solarpaletten/ypl.git
cd ypl

# 2️⃣ Распаковать архив (в отдельной папке)
# На Windows: Правый клик → Извлечь всё
# На Mac: Двойной клик на ypl-core.zip
# На Linux:
unzip ~/Downloads/ypl-core.zip -d ~/Downloads/

# 3️⃣ Скопировать файлы в репозиторий
# ВАЖНО: Копируем СОДЕРЖИМОЕ папки ypl-core, не саму папку!

# На Mac/Linux:
cp -r ~/Downloads/ypl-core/* ./
cp ~/Downloads/ypl-core/.gitignore ./

# На Windows (PowerShell):
# Copy-Item -Path "C:\Users\USER\Downloads\ypl-core\*" -Destination ".\" -Recurse
# Copy-Item -Path "C:\Users\USER\Downloads\ypl-core\.gitignore" -Destination ".\"

# 4️⃣ Проверить структуру
ls -la
# Должно показать:
# - frontend/
# - backend/
# - docs/
# - vercel.json
# - README.md
# - LICENSE
# - .gitignore

# 5️⃣ Добавить все файлы в Git
git add .

# 6️⃣ Проверить что добавлено
git status
# Должно показать много "new file:"

# 7️⃣ Создать коммит
git commit -m "Initial YPL CORE v1.0 upload

- Landing page (Next.js + Tailwind)
- Backend structure (Express)
- Documentation (Architecture, Roadmap, Protocol)
- Vercel deployment config
- CI/CD ready

Team: Leanid (Architect), Dashka (Coordinator), Vasil (President), Claude (Engineer)"

# 8️⃣ Отправить в GitHub
git push origin main

# ═══════════════════════════════════════════════════════════
# ✅ ГОТОВО! Код на GitHub!
# ═══════════════════════════════════════════════════════════
```

---

### Вариант B: Если в репозитории уже есть файлы

```bash
# ═══════════════════════════════════════════════════════════
# ЕСЛИ НУЖНО ЗАМЕНИТЬ СУЩЕСТВУЮЩИЕ ФАЙЛЫ
# ═══════════════════════════════════════════════════════════

# 1️⃣ Клонировать репозиторий
git clone https://github.com/Solarpaletten/ypl.git
cd ypl

# 2️⃣ Удалить старые файлы (кроме .git!)
# На Mac/Linux:
rm -rf frontend backend docs
rm -f vercel.json README.md LICENSE

# На Windows (PowerShell):
# Remove-Item -Recurse -Force frontend, backend, docs
# Remove-Item vercel.json, README.md, LICENSE -ErrorAction SilentlyContinue

# 3️⃣ Скопировать новые файлы из архива
cp -r ~/Downloads/ypl-core/* ./
cp ~/Downloads/ypl-core/.gitignore ./

# 4️⃣ Проверить структуру
ls -la

# 5️⃣ Добавить изменения
git add .

# 6️⃣ Коммит
git commit -m "Update to YPL CORE v1.0

Complete project restructure with:
- Next.js 14 frontend
- Express backend
- Full documentation
- Vercel deployment config"

# 7️⃣ Push
git push origin main

# ═══════════════════════════════════════════════════════════
# ✅ ГОТОВО!
# ═══════════════════════════════════════════════════════════
```

---

## 🌿 Создание ветки dev

После успешного push в main:

```bash
# ═══════════════════════════════════════════════════════════
# СОЗДАНИЕ ВЕТКИ DEV
# ═══════════════════════════════════════════════════════════

# 1️⃣ Убедиться что на main
git checkout main
git pull origin main

# 2️⃣ Создать ветку dev
git checkout -b dev

# 3️⃣ Push ветки dev
git push -u origin dev

# 4️⃣ Вернуться на main (опционально)
git checkout main

# ═══════════════════════════════════════════════════════════
# ✅ Теперь есть main и dev ветки!
# ═══════════════════════════════════════════════════════════
```

---

## 🔗 Подключение Vercel

### Шаг 1: Войти в Vercel

1. Открыть https://vercel.com
2. Войти через GitHub (Solarpaletten)

### Шаг 2: Импортировать проект

1. Нажать **"Add New..."** → **"Project"**
2. Выбрать репозиторий **Solarpaletten/ypl**
3. Нажать **"Import"**

### Шаг 3: Настроить проект

```
┌─────────────────────────────────────────────────────────────┐
│ Configure Project                                           │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│ Project Name:         ypl                                   │
│                                                             │
│ Framework Preset:     Next.js   ✅ (auto-detected)         │
│                                                             │
│ Root Directory:       frontend  ⚠️ ВАЖНО! Изменить!        │
│                       [Edit] → frontend → [Continue]        │
│                                                             │
│ Build Settings:                                             │
│   Build Command:      npm run build   (default OK)          │
│   Output Directory:   .next           (default OK)          │
│   Install Command:    npm install     (default OK)          │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

**⚠️ КРИТИЧНО: Root Directory = `frontend`**

### Шаг 4: Деплой

1. Нажать **"Deploy"**
2. Ждать ~1-2 минуты
3. Получить URL: `ypl-xxx.vercel.app`

### Шаг 5: Добавить домен

1. Перейти в **Settings** → **Domains**
2. Добавить: `ypl.app`
3. Следовать инструкциям DNS (см. DNS_SETUP.md)

---

## 🌐 Настройка доменов в Vercel

### Production (main → ypl.app)

```
Domain:     ypl.app
Branch:     main
```

### Staging (dev → dev.ypl.app)

```
Domain:     dev.ypl.app
Branch:     dev
```

### Как добавить:

1. **Settings** → **Domains**
2. Ввести `dev.ypl.app`
3. Выбрать **Git Branch**: `dev`
4. **Add**

---

## ✅ Чек-лист после push

```
[ ] Код загружен в GitHub
[ ] Ветка main существует
[ ] Ветка dev создана
[ ] Vercel проект создан
[ ] Root directory = frontend
[ ] Первый деплой успешен
[ ] ypl.app добавлен в domains
[ ] dev.ypl.app добавлен в domains
[ ] DNS настроен (см. DNS_SETUP.md)
[ ] SSL сертификат активен
[ ] Сайт открывается: https://ypl.app
```

---

## 🔧 Возможные проблемы

### Проблема: "Permission denied"

```bash
# Решение: Настроить SSH ключ
ssh-keygen -t ed25519 -C "your@email.com"
cat ~/.ssh/id_ed25519.pub
# Добавить ключ в GitHub → Settings → SSH Keys
```

### Проблема: "Repository not found"

```bash
# Решение: Проверить URL
git remote -v
# Должно показать: https://github.com/Solarpaletten/ypl.git
```

### Проблема: Build failed в Vercel

```bash
# Проверить логи в Vercel Dashboard
# Частые причины:
# 1. Root directory не установлен в "frontend"
# 2. Ошибки в package.json
# 3. TypeScript ошибки
```

### Проблема: "Cannot find module"

```bash
# Локально выполнить:
cd frontend
npm install
npm run build
# Исправить ошибки перед push
```

---

## 📊 Ожидаемый результат

После выполнения всех шагов:

```
GitHub Repository
└── https://github.com/Solarpaletten/ypl
    ├── main branch → ypl.app (Production)
    └── dev branch  → dev.ypl.app (Staging)

Vercel Deployments
├── Production: https://ypl.app
├── Staging:    https://dev.ypl.app
└── Preview:    https://ypl-xxx.vercel.app
```

---

## 📞 Поддержка

Проблемы с деплоем?

| Вопрос | Контакт |
|--------|---------|
| Git/GitHub | Claude |
| Vercel | Claude |
| DNS | Claude |
| Стратегия | Leanid |
| Координация | Dashka |

---

© 2025 YPL GRUP INC
